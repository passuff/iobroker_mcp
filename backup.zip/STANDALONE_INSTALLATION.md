# Standalone MCP Server für ioBroker - Installation

## Übersicht

Der Standalone MCP Server ermöglicht es Cursor (oder anderen AI-Assistenten), mit deinem ioBroker System zu kommunizieren - ohne einen Adapter installieren zu müssen!

## Vorteile

✅ **Keine ioBroker-Installation nötig** - Läuft auf deinem Windows-PC  
✅ **Einfache Konfiguration** - Nur IP und Port angeben  
✅ **Sofort einsatzbereit** - Nach 5 Minuten fertig  
✅ **REST API basiert** - Nutzt die Standard ioBroker API

## Installation in 5 Schritten

### 1. Voraussetzungen prüfen

- Node.js installiert? Test: `node --version` im Terminal
- ioBroker REST API aktiviert? (Admin → Einstellungen → API)
- Netzwerkverbindung zu ioBroker möglich?

### 2. Installation

```bash
# In das Verzeichnis wechseln
cd C:\prog\iobroker_mcp\standalone-mcp-server

# Installation ausführen
install.bat
```

### 3. Konfiguration

Bearbeite die `.env` Datei:

```env
# ioBroker Connection
IOBROKER_HOST=192.168.1.19    # Deine ioBroker IP
IOBROKER_PORT=8087             # Standard REST API Port

# Optional: Falls Authentifizierung aktiviert
# IOBROKER_USER=admin
# IOBROKER_PASSWORD=dein-passwort
```

### 4. Test

```bash
# Server testen
test-server.bat
```

Der MCP Inspector öffnet sich im Browser. Teste z.B.:
- Tool: `getState`
- ID: `system.adapter.admin.0.alive`

### 5. Cursor Integration

In Cursor: Settings → MCP → Edit settings.json

```json
{
  "mcpServers": {
    "iobroker": {
      "command": "node",
      "args": ["C:\\prog\\iobroker_mcp\\standalone-mcp-server\\dist\\index.js"]
    }
  }
}
```

## Verfügbare Tools

| Tool | Beschreibung | Beispiel |
|------|--------------|----------|
| `getState` | Liest einen State | `system.adapter.admin.0.alive` |
| `setState` | Schreibt einen State | `hm-rpc.0.ABC.1.STATE` = true |
| `getStates` | Liest mehrere States | Pattern: `hm-rpc.0.*` |
| `getObject` | Liest ein Objekt | `system.adapter.admin.0` |
| `getObjects` | Liest mehrere Objekte | Type: `device` |
| `sendTo` | Sendet Nachricht an Adapter | `telegram.0` → "Hallo" |

## Beispiele in Cursor

Nach der Installation kannst du in Cursor einfach schreiben:

- "Zeige mir alle Homematic Geräte"
- "Schalte das Licht im Wohnzimmer ein"
- "Wie ist die aktuelle Temperatur im Schlafzimmer?"
- "Sende eine Telegram-Nachricht: System gestartet"

## Fehlerbehebung

### "Connection refused"
```bash
# Prüfe ob ioBroker erreichbar ist
curl http://192.168.1.19:8087/api/v1/system/alive
```

### "Authentication failed"
- REST API Benutzer/Passwort in .env eintragen
- In ioBroker Admin prüfen ob API-Zugriff erlaubt ist

### Server startet nicht
```bash
# Logs prüfen
node dist/index.js
```

## Nächste Schritte

1. **Sicherheit**: Für Produktivbetrieb HTTPS und Authentifizierung aktivieren
2. **Performance**: Bei vielen Zugriffen Cache implementieren
3. **Erweitern**: Eigene Tools in `src/index.ts` hinzufügen

## Support

- Probleme? Check die Logs in Cursor: Help → Toggle Developer Tools
- REST API Doku: http://deine-iobroker-ip:8087/api/v1/
- MCP Doku: https://modelcontextprotocol.io/ 