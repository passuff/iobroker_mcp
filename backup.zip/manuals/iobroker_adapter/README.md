---
title: Development
lastChanged: 21.21.2019
translatedFrom: de
translatedWarning: If you want to edit this document please delete "translatedFrom" field, elsewise this document will be translated automatically again
editLink: https://github.com/ioBroker/ioBroker.docs/edit/master/docs/en/dev/README.md
hash: Kx17URyXBkdLC6E3X5WTP2fuyYAltLWfm1Tmurl+85E=
---
# Adapter development
?> ***This is a placeholder***.<br><br> Help ioBroker and expand this article. Please note the [ioBroker Style Guide](community/styleguidedoc) so that the changes can be adopted more easily.

## Useful links
### Translation help
[https://translator.iobroker.in/](https://translator.iobroker.in/) - with this you can translate the texts into 9 languages and the result can be used directly in words.js

image

### Adapter checker
[https://adapter-check.iobroker.in/](https://adapter-check.iobroker.in/)

image

### Adapter creator
[https://adapter-creator.iobroker.in/](https://adapter-creator.iobroker.in/)

image