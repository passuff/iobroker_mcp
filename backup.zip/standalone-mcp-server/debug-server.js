#!/usr/bin/env node

import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

console.log('Starting MCP Server in debug mode...');
console.log('Server path:', join(__dirname, 'dist', 'index.js'));

const server = spawn('node', [join(__dirname, 'dist', 'index.js')], {
  stdio: ['pipe', 'pipe', 'inherit'],
  env: { ...process.env, DEBUG: 'mcp:*' }
});

// Test initial handshake
const initRequest = {
  jsonrpc: '2.0',
  id: 1,
  method: 'initialize',
  params: {
    protocolVersion: '2024-11-05',
    capabilities: {},
    clientInfo: {
      name: 'debug-client',
      version: '1.0.0'
    }
  }
};

console.log('Sending initialize request...');
server.stdin.write(JSON.stringify(initRequest) + '\n');

// Listen for responses
server.stdout.on('data', (data) => {
  const lines = data.toString().split('\n').filter(line => line.trim());
  lines.forEach(line => {
    try {
      const response = JSON.parse(line);
      console.log('Response:', JSON.stringify(response, null, 2));
      
      // If initialization successful, list tools
      if (response.id === 1 && response.result) {
        console.log('\nInitialization successful! Requesting tools list...');
        const toolsRequest = {
          jsonrpc: '2.0',
          id: 2,
          method: 'tools/list',
          params: {}
        };
        server.stdin.write(JSON.stringify(toolsRequest) + '\n');
      }
      
      // Show tools list
      if (response.id === 2 && response.result && response.result.tools) {
        console.log('\nAvailable tools:');
        response.result.tools.forEach(tool => {
          console.log(`- ${tool.name}: ${tool.description}`);
        });
        
        // Clean exit
        setTimeout(() => {
          console.log('\nDebug complete. Exiting...');
          server.kill();
          process.exit(0);
        }, 1000);
      }
    } catch (e) {
      console.error('Failed to parse response:', line);
    }
  });
});

server.on('error', (err) => {
  console.error('Server error:', err);
});

server.on('exit', (code) => {
  console.log('Server exited with code:', code);
});

// Timeout after 10 seconds
setTimeout(() => {
  console.error('\nTimeout: No proper response from server');
  server.kill();
  process.exit(1);
}, 10000); 