import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import axios, { AxiosInstance } from 'axios';
import { z } from 'zod';
import * as dotenv from 'dotenv';

dotenv.config();

// Configuration
const IOBROKER_HOST = process.env.IOBROKER_HOST || '192.168.1.19';
const IOBROKER_PORT = process.env.IOBROKER_PORT || '8087';
const IOBROKER_PROTOCOL = process.env.IOBROKER_PROTOCOL || 'http';
const IOBROKER_USER = process.env.IOBROKER_USER;
const IOBROKER_PASSWORD = process.env.IOBROKER_PASSWORD;

// Create axios instance with auth if provided
const api: AxiosInstance = axios.create({
  baseURL: `${IOBROKER_PROTOCOL}://${IOBROKER_HOST}:${IOBROKER_PORT}`,
  timeout: 10000,
  ...(IOBROKER_USER && IOBROKER_PASSWORD && {
    auth: {
      username: IOBROKER_USER,
      password: IOBROKER_PASSWORD,
    },
  }),
});

// Tool schemas
const GetStateSchema = z.object({
  id: z.string().describe('State ID (e.g., "hm-rpc.0.ABC123.1.STATE")'),
});

const SetStateSchema = z.object({
  id: z.string().describe('State ID'),
  value: z.any().describe('Value to set'),
  ack: z.boolean().optional().default(false).describe('Acknowledged flag'),
});

const GetStatesSchema = z.object({
  pattern: z.string().optional().describe('Pattern to filter states (e.g., "hm-rpc.0.*")'),
});

const GetObjectSchema = z.object({
  id: z.string().describe('Object ID'),
});

const GetObjectsSchema = z.object({
  pattern: z.string().optional().describe('Pattern to filter objects'),
  type: z.string().optional().describe('Object type (e.g., "state", "channel", "device")'),
});

const SendToSchema = z.object({
  instance: z.string().describe('Adapter instance (e.g., "telegram.0")'),
  command: z.string().describe('Command to send'),
  message: z.any().optional().describe('Message payload'),
});

// Create MCP server
const server = new Server(
  {
    name: 'iobroker-mcp-server',
    vendor: 'standalone',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Helper function to check connection
async function checkConnection(): Promise<boolean> {
  try {
    // Use simple API endpoint to check connection
    await api.get('/');
    return true;
  } catch (error) {
    console.error('Failed to connect to ioBroker:', error);
    return false;
  }
}

// Tool handlers
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: 'getState',
      description: 'Get a state value from ioBroker',
      inputSchema: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'State ID (e.g., "hm-rpc.0.ABC123.1.STATE")'
          }
        },
        required: ['id']
      },
    },
    {
      name: 'setState',
      description: 'Set a state value in ioBroker',
      inputSchema: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'State ID'
          },
          value: {
            description: 'Value to set'
          },
          ack: {
            type: 'boolean',
            description: 'Acknowledged flag',
            default: false
          }
        },
        required: ['id', 'value']
      },
    },
    {
      name: 'getStates',
      description: 'Get multiple states from ioBroker with optional pattern',
      inputSchema: {
        type: 'object',
        properties: {
          pattern: {
            type: 'string',
            description: 'Pattern to filter states (e.g., "hm-rpc.0.*")'
          }
        }
      },
    },
    {
      name: 'getObject',
      description: 'Get an object from ioBroker',
      inputSchema: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'Object ID'
          }
        },
        required: ['id']
      },
    },
    {
      name: 'getObjects',
      description: 'Get multiple objects from ioBroker with optional pattern and type filter',
      inputSchema: {
        type: 'object',
        properties: {
          pattern: {
            type: 'string',
            description: 'Pattern to filter objects'
          },
          type: {
            type: 'string',
            description: 'Object type (e.g., "state", "channel", "device")'
          }
        }
      },
    },
    {
      name: 'sendTo',
      description: 'Send a message to an adapter instance',
      inputSchema: {
        type: 'object',
        properties: {
          instance: {
            type: 'string',
            description: 'Adapter instance (e.g., "telegram.0")'
          },
          command: {
            type: 'string',
            description: 'Command to send'
          },
          message: {
            description: 'Message payload'
          }
        },
        required: ['instance', 'command']
      },
    },
  ],
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case 'getState': {
        const { id } = GetStateSchema.parse(args);
        const response = await api.get(`/get/${id}`);
        
        if (!response.data) {
          return {
            content: [{
              type: 'text',
              text: `State ${id} not found`,
            }],
          };
        }
        
        return {
          content: [{
            type: 'text',
            text: JSON.stringify({
              id,
              val: response.data.val,
              ack: response.data.ack,
              ts: response.data.ts,
              lc: response.data.lc,
              from: response.data.from,
              q: response.data.q,
            }, null, 2),
          }],
        };
      }

      case 'setState': {
        const { id, value, ack } = SetStateSchema.parse(args);
        // Simple API uses query parameters
        const response = await api.get(`/set/${id}`, {
          params: {
            value: value,
            ack: ack ? 'true' : 'false'
          }
        });
        
        return {
          content: [{
            type: 'text',
            text: `State ${id} set to ${JSON.stringify(value)} (ack: ${ack})`,
          }],
        };
      }

      case 'getStates': {
        const { pattern } = GetStatesSchema.parse(args);
        // Simple API uses /states endpoint with pattern parameter
        const response = await api.get('/states', {
          params: pattern ? { pattern } : undefined,
        });
        
        const states = response.data || {};
        const count = Object.keys(states).length;
        
        // Format the states output
        let formattedStates: Record<string, any> = {};
        for (const [key, value] of Object.entries(states)) {
          formattedStates[key] = value;
        }
        
        return {
          content: [{
            type: 'text',
            text: `Found ${count} states${pattern ? ` matching pattern "${pattern}"` : ''}:\n${JSON.stringify(formattedStates, null, 2)}`,
          }],
        };
      }

      case 'getObject': {
        const { id } = GetObjectSchema.parse(args);
        // Simple API uses /objects endpoint
        const response = await api.get('/objects', {
          params: { pattern: id }
        });
        
        const objects = response.data || {};
        if (!objects[id]) {
          return {
            content: [{
              type: 'text',
              text: `Object ${id} not found`,
            }],
          };
        }
        
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(objects[id], null, 2),
          }],
        };
      }

      case 'getObjects': {
        const { pattern, type } = GetObjectsSchema.parse(args);
        // Simple API uses /objects endpoint
        const response = await api.get('/objects', {
          params: {
            pattern: pattern || '*',
            type,
          },
        });
        
        const objects = response.data || {};
        const count = Object.keys(objects).length;
        
        // Filter by type if specified
        let filteredObjects: Record<string, any> = objects;
        if (type) {
          filteredObjects = {};
          for (const [key, obj] of Object.entries(objects)) {
            if ((obj as any).type === type) {
              filteredObjects[key] = obj;
            }
          }
        }
        
        return {
          content: [{
            type: 'text',
            text: `Found ${Object.keys(filteredObjects).length} objects${pattern ? ` matching pattern "${pattern}"` : ''}${type ? ` of type "${type}"` : ''}:\n${JSON.stringify(filteredObjects, null, 2)}`,
          }],
        };
      }

      case 'sendTo': {
        const { instance, command, message } = SendToSchema.parse(args);
        // Simple API doesn't have direct sendTo support, return error message
        return {
          content: [{
            type: 'text',
            text: `Error: sendTo is not supported via Simple API. Please use the socket.io connection or admin interface for this functionality.`,
          }],
        };
      }

      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const status = error.response?.status;
      const message = error.response?.data?.error || error.response?.data || error.message;
      
      if (status === 404) {
        return {
          content: [{
            type: 'text',
            text: `Not found: ${message}`,
          }],
        };
      } else if (status === 401) {
        return {
          content: [{
            type: 'text',
            text: 'Authentication failed. Please check your credentials in .env file.',
          }],
        };
      } else if (status === 403) {
        return {
          content: [{
            type: 'text',
            text: 'Access denied. Please check your permissions.',
          }],
        };
      }
      
      return {
        content: [{
          type: 'text',
          text: `Error: ${message} (Status: ${status || 'unknown'})`,
        }],
      };
    }
    
    return {
      content: [{
        type: 'text',
        text: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
      }],
    };
  }
});

// Start server
async function main() {
  console.error(`Connecting to ioBroker at ${IOBROKER_PROTOCOL}://${IOBROKER_HOST}:${IOBROKER_PORT}...`);
  
  const connected = await checkConnection();
  if (!connected) {
    console.error('Failed to connect to ioBroker. Please check:');
    console.error('1. ioBroker is running');
    console.error('2. REST API is enabled');
    console.error('3. Host and port are correct in .env file');
    console.error('4. Firewall allows connection');
    process.exit(1);
  }
  
  console.error('Successfully connected to ioBroker!');
  
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('MCP Server running on stdio');
}

main().catch(console.error); 