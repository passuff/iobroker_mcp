# Cursor Integration für ioBroker MCP Server

## Voraussetzungen

1. ioBroker läuft und ist erreichbar
2. REST API in ioBroker ist aktiviert
3. Node.js ist auf deinem Windows-PC installiert
4. Der Standalone MCP Server ist installiert und gebaut

## Installation des MCP Servers

1. Öffne ein Terminal im `standalone-mcp-server` Verzeichnis
2. Führe aus: `install.bat`
3. Bearbeite die `.env` Datei mit deinen ioBroker-Einstellungen:
   ```env
   IOBROKER_HOST=192.168.1.19
   IOBROKER_PORT=8087
   ```

## Cursor Konfiguration

1. Öffne Cursor
2. Gehe zu: File → Preferences → Settings
3. Suche nach "MCP"
4. Klicke auf "Edit in settings.json"

5. Füge folgende Konfiguration hinzu:

```json
{
  "mcpServers": {
    "iobroker": {
      "command": "node",
      "args": ["C:\\prog\\iobroker_mcp\\standalone-mcp-server\\dist\\index.js"],
      "env": {
        "NODE_ENV": "production"
      }
    }
  }
}
```

**Wichtig**: Passe den Pfad an deine Installation an!

## Alternative: Mit MCP-Proxy für Remote-Zugriff

Wenn du den MCP-Server nicht lokal laufen lassen möchtest:

1. Installiere den MCP-Proxy auf dem ioBroker-System
2. Konfiguriere Cursor für Remote-Zugriff:

```json
{
  "mcpServers": {
    "iobroker-remote": {
      "transport": {
        "type": "sse",
        "url": "http://192.168.1.19:3000/sse"
      }
    }
  }
}
```

## Verfügbare Befehle in Cursor

Nach der Konfiguration kannst du in Cursor folgende Befehle nutzen:

### States lesen:
```
Zeige mir den Wert von system.adapter.admin.0.alive
```

### States schreiben:
```
Setze den State hm-rpc.0.ABC123.1.STATE auf true
```

### Mehrere States abrufen:
```
Liste alle States die mit hm-rpc.0 beginnen
```

### Objekte abrufen:
```
Zeige mir das Objekt system.adapter.admin.0
```

### Nachrichten senden:
```
Sende eine Nachricht an telegram.0 mit dem Text "Hallo von Cursor"
```

## Fehlerbehebung

### "Connection refused"
- Prüfe ob ioBroker läuft
- Prüfe ob die REST API aktiviert ist
- Prüfe die Firewall-Einstellungen

### "Authentication failed"
- Prüfe Benutzername und Passwort in der .env Datei
- Stelle sicher, dass der Benutzer API-Zugriff hat

### "Tool not found"
- Starte Cursor neu nach Konfigurationsänderungen
- Prüfe ob der MCP-Server läuft (Task-Manager)

## Test der Verbindung

1. Öffne ein Terminal
2. Führe aus: `test-server.bat`
3. Der MCP Inspector öffnet sich im Browser
4. Teste die verschiedenen Tools

## Tipps

1. **Performance**: Für bessere Performance nutze spezifische State-IDs statt Patterns
2. **Sicherheit**: Nutze HTTPS und Authentifizierung in Produktivumgebungen
3. **Logging**: Prüfe die Cursor Developer Tools (Help → Toggle Developer Tools) für Fehler 