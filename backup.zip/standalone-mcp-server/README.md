# Standalone MCP Server for ioBroker

A lightweight MCP (Model Context Protocol) server that connects to ioBroker via REST API.

## Features

- No ioBroker adapter installation required
- Works with any ioBroker instance with REST API enabled
- Simple configuration via environment variables
- Basic state and object operations

## Prerequisites

- Node.js 18 or higher
- ioBroker with REST API enabled
- Network access to ioBroker instance

## Installation

```bash
# Clone or download this folder
cd standalone-mcp-server

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Edit .env with your ioBroker settings
```

## Configuration

Edit `.env` file:

```env
IOBROKER_HOST=192.168.1.19
IOBROKER_PORT=8087
IOBROKER_PROTOCOL=http
```

## Usage

### Direct usage with stdio:

```bash
npm run build
npm start
```

### With MCP Inspector:

```bash
npx @modelcontextprotocol/inspector npm start
```

### With Cursor:

Add to Cursor MCP settings:

```json
{
  "mcpServers": {
    "iobroker": {
      "command": "node",
      "args": ["C:/path/to/standalone-mcp-server/dist/index.js"]
    }
  }
}
```

## Available Tools

- `getState` - Read a single state
- `setState` - Write a state value
- `getStates` - Read multiple states with pattern
- `getObject` - Get object information

## Limitations

Compared to the full adapter approach, this standalone server:
- Cannot subscribe to state changes (no real-time events)
- Cannot send messages between adapters
- Has higher latency due to HTTP overhead
- Requires REST API to be enabled and accessible

## When to Use

This standalone approach is ideal when:
- You need quick access to ioBroker from AI assistants
- You don't want to modify your ioBroker installation
- You only need basic read/write operations
- You're prototyping or testing 